<?php
// Initialize the session
session_start();

// check untuk login session, jika tidak akan dibuang ke halaman login
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Welcome</title>
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <style>
        body {
            font: 14px sans-serif;
            text-align: center;
        }
    </style>
</head>

<body class="card o-hidden border-0 shadow-lg my-5">
    <div>
        <h1 class="my-5">Hi, <b><?php echo htmlspecialchars($_SESSION["username"]); ?></b>. Welcome to our site.</h1>
        <p>
            <a href="index_admin.php" class="btn btn-primary  ml-3">Buka Dashboard</a>
            <a href="reset-password.php" class="btn btn-warning  ml-3">Ubah Sandi</a>
            <a href="logout.php" class="btn btn-danger ml-3">Sign Out</a>
        </p>
    </div>
    <footer class="sticky-footer bg-white">
        <div class="container my-auto">
            <div class="copyright text-center my-auto">
                <span>Copyright &copy; Sertifikasi Fatur 2023</span>
            </div>
        </div>
    </footer>
</body>

</html>